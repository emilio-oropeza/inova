var jugadores = [
	{
		"nombre": "Gareth Bale",
		"pais": "Gales",
		"goles": 3,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Alvaro Morata",
		"pais": "España",
		"goles": 3,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Antonie Griezmann",
		"pais": "Francia",
		"goles": 3,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Cristiano Ronaldo",
		"pais": "Portugal",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Romelu Lukaku",
		"pais": "Bélgica",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},	
	{
		"nombre": "Dimitri Payet",
		"pais": "Francia",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	
	{
		"nombre": "Nani",
		"pais": "Portugal",
		"goles": 2,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Mario Gómez",
		"pais": "Alemania",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 9
		}
	},
	{
		"nombre": "Bogdan Stancu",
		"pais": "Rumania",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 3
		}
	},
	{
		"nombre": "Eden Hazard",
		"pais": "Bélgica",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	}
];