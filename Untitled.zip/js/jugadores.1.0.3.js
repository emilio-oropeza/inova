var jugadores = [
	{
		"nombre": "Paul Pogba",
		"pais": "Francia",
		"goles": 0,
		"tenis": {
			"marca": "adidas",
			"modelo": 3
		}
	},
	{
		"nombre": "Cristiano Ronaldo",
		"pais": "Portugal",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Gareth Bale",
		"pais": "Gales",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Zlatan Ibrahimovic",
		"pais": "Suecia",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Thomas Müller",
		"pais": "Alemania",
		"goles": 0,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Luka Modric",
		"pais": "Croacia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 3
		}
	},
	{
		"nombre": "Antonie Griezmann",
		"pais": "Francia",
		"goles": 0,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Robert Lewandowski",
		"pais": "Polonia",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 8
		}
	},
	{
		"nombre": "Sergio Ramos",
		"pais": "España",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	{
		"nombre": "Wayne Rooney",
		"pais": "Inglaterra",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	}
];