var jugadores = [
	{
		"nombre": "Antonie Griezmann",
		"pais": "Francia",
		"goles": 4,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Gareth Bale",
		"pais": "Gales",
		"goles": 3,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},	
	{
		"nombre": "Dimitri Payet",
		"pais": "Francia",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Oliver Giroud",
		"pais": "Francia",
		"goles": 3,
		"tenis": {
			"marca": "puma",
			"modelo": 2
		}
	},
	{
		"nombre": "Alvaro Morata",
		"pais": "España",
		"goles": 3,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Cristiano Ronaldo",
		"pais": "Portugal",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Mario Gómez",
		"pais": "Alemania",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 9
		}
	},	
	{
		"nombre": "Nani",
		"pais": "Portugal",
		"goles": 2,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Romelu Lukaku",
		"pais": "Bélgica",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Bogdan Stancu",
		"pais": "Rumania",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 3
		}
	}
];