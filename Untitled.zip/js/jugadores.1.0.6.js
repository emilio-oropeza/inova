var jugadores = [
	{
		"nombre": "Gareth Bale",
		"pais": "Gales",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Luka Modric",
		"pais": "Croacia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Bastian Schweinsteiger",
		"pais": "Alemania",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Oliver Giroud",
		"pais": "Francia",
		"goles": 1,
		"tenis": {
			"marca": "puma",
			"modelo": 2
		}
	},
	{
		"nombre": "Dimitri Payet",
		"pais": "Francia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Nani",
		"pais": "Portugal",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Gerard Piqué",
		"pais": "España",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	{
		"nombre": "Eric Dier",
		"pais": "Inglaterra",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 2
		}
	},
	{
		"nombre": "Graziano Pellè",
		"pais": "Italia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Arkadiusz Milik",
		"pais": "Polonia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Emanuele Giaccherini",
		"pais": "Italia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Shkodran Mustafi",
		"pais": "Alemania",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 1
		}
	},
	{
		"nombre": "Ondrej Duda",
		"pais": "Eslovaquia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Hal Robson-Kanu",
		"pais": "Gales",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Wes Hoolahan",
		"pais": "Irlanda",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	{
		"nombre": "Bogdan Stancu",
		"pais": "Rumania",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 3
		}
	},
	{
		"nombre": "Vasili Berezutskiy",
		"pais": "Rusia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Fabian Schär",
		"pais": "Suiza",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 1
		}
	},
	{
		"nombre": "Adam Szalai",
		"pais": "Hungría",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Zlotan Stieber",
		"pais": "Hungría",
		"goles": 1,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Bjarnason",
		"pais": "Islandia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 1
		}
	},
	{
		"nombre": "Paul Pogba",
		"pais": "Francia",
		"goles": 0,
		"tenis": {
			"marca": "adidas",
			"modelo": 3
		}
	},
	{
		"nombre": "Cristiano Ronaldo",
		"pais": "Portugal",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	
	{
		"nombre": "Zlatan Ibrahimovic",
		"pais": "Suecia",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Thomas Müller",
		"pais": "Alemania",
		"goles": 0,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	
	{
		"nombre": "Antonie Griezmann",
		"pais": "Francia",
		"goles": 0,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Robert Lewandowski",
		"pais": "Polonia",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 8
		}
	},
	{
		"nombre": "Sergio Ramos",
		"pais": "España",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	{
		"nombre": "Wayne Rooney",
		"pais": "Inglaterra",
		"goles": 0,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	}
];