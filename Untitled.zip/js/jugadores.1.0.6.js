var jugadores = [
	{
		"nombre": "Gareth Bale",
		"pais": "Gales",
		"goles": 2,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Alvaro Morata",
		"pais": "España",
		"goles": 2,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Dimitri Payet",
		"pais": "Francia",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Romelu Lukaku",
		"pais": "Bélgica",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Bogdan Stancu",
		"pais": "Rumania",
		"goles": 2,
		"tenis": {
			"marca": "nike",
			"modelo": 3
		}
	},
	{
		"nombre": "Luka Modric",
		"pais": "Croacia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Bastian Schweinsteiger",
		"pais": "Alemania",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Oliver Giroud",
		"pais": "Francia",
		"goles": 1,
		"tenis": {
			"marca": "puma",
			"modelo": 2
		}
	},	
	{
		"nombre": "Nani",
		"pais": "Portugal",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Gerard Piqué",
		"pais": "España",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	{
		"nombre": "Eric Dier",
		"pais": "Inglaterra",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 2
		}
	},

























	
	{
		"nombre": "Graziano Pellè",
		"pais": "Italia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 5
		}
	},
	{
		"nombre": "Arkadiusz Milik",
		"pais": "Polonia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Emanuele Giaccherini",
		"pais": "Italia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 0
		}
	},
	{
		"nombre": "Shkodran Mustafi",
		"pais": "Alemania",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 1
		}
	},
	{
		"nombre": "Ondrej Duda",
		"pais": "Eslovaquia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Hal Robson-Kanu",
		"pais": "Gales",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 5
		}
	},
	{
		"nombre": "Wes Hoolahan",
		"pais": "Irlanda",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 0
		}
	},
	
	{
		"nombre": "Vasili Berezutskiy",
		"pais": "Rusia",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 4
		}
	},
	{
		"nombre": "Fabian Schär",
		"pais": "Suiza",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 1
		}
	},
	{
		"nombre": "Adam Szalai",
		"pais": "Hungría",
		"goles": 1,
		"tenis": {
			"marca": "nike",
			"modelo": 7
		}
	},
	{
		"nombre": "Zlotan Stieber",
		"pais": "Hungría",
		"goles": 1,
		"tenis": {
			"marca": "puma",
			"modelo": 0
		}
	},
	{
		"nombre": "Bjarnason",
		"pais": "Islandia",
		"goles": 1,
		"tenis": {
			"marca": "adidas",
			"modelo": 1
		}
	}
];