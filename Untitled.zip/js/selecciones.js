var selecciones = [
	{
		"nombre": "Albania",
		"tenis":[]
	},
	{
		"nombre": "Alemania",
		"tenis":[]
	},
	{
		"nombre": "Austria",
		"tenis":[]
	},
	{
		"nombre": "Bélgica",
		"tenis":[]
	},
	{
		"nombre": "Coracia",
		"tenis":[
			{
				"marca": "nike",
				"modelo": 3,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Eslovaquia",
		"tenis":[
			{
				"marca": "adidas",
				"modelo": 6,
				"goles": 1
			}
		]
	},
	{
		"nombre": "España",
		"tenis":[]
	},
	{
		"nombre": "Francia",
		"tenis":[
			{
				"marca": "nike",
				"modelo": 5,
				"goles": 1
			},			
			{
				"marca": "puma",
				"modelo": 2,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Gales",
		"tenis":[
			{
				"marca": "adidas",
				"modelo": 0,
				"goles": 1
			},
			{
				"marca": "adidas",
				"modelo": 5,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Hungría",
		"tenis":[]
	},
	{
		"nombre": "Inglaterra",
		"tenis":[
			{
				"marca": "nike",
				"modelo": 2,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Irlanda del Norte",
		"tenis":[]
	},
	{
		"nombre": "Islandia",
		"tenis":[]
	},
	{
		"nombre": "Italia",
		"tenis":[]
	},
	{
		"nombre": "Polonia",
		"tenis":[
			{
				"marca": "nike",
				"modelo": 7,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Portugal",
		"tenis":[]
	},
	{
		"nombre": "República Checa",
		"tenis":[]
	},
	{
		"nombre": "República de Irlanda",
		"tenis":[]
	},
	{
		"nombre": "Rumanía",
		"tenis":[
			{
				"marca": "nike",
				"modelo": 3,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Rusia",
		"tenis":[
			{
				"marca": "adidas",
				"modelo": 0,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Suecia",
		"tenis":[]
	},
	{
		"nombre": "Suiza",
		"tenis":[
			{
				"marca": "adidas",
				"modelo": 1,
				"goles": 1
			}
		]
	},
	{
		"nombre": "Turquía",
		"tenis":[]
	},
	{
		"nombre": "Ucrania",
		"tenis":[]
	}
];